<?php $__env->startSection('title', 'Sıkça Sorulan Sorular - UKPower'); ?>

<?php $__env->startSection('content'); ?>

<section class="bg-gradient-to-r from-blue-600 to-green-500 text-white py-16">
    <div class="container mx-auto px-4">
        <h1 class="text-4xl font-bold mb-4">Sıkça Sorulan Sorular</h1>
        <p class="text-xl">Güneş enerjisi hakkında merak ettikleriniz</p>
    </div>
</section>


<section class="py-16">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl mx-auto">
            <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $categoryFaqs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mb-8">
                    <h2 class="text-2xl font-bold text-gray-900 mb-6 capitalize">
                        <?php echo e($category == 'ges' ? 'Güneş Enerjisi Santralleri' : ($category == 'res' ? 'Rüzgar Santralleri' : 'Genel')); ?>

                    </h2>
                    
                    <div class="space-y-4">
                        <?php $__currentLoopData = $categoryFaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bg-white rounded-lg shadow-md overflow-hidden">
                            <button class="faq-question w-full text-left px-6 py-4 flex justify-between items-center hover:bg-gray-50 transition">
                                <span class="font-semibold text-gray-900 pr-4"><?php echo e($faq->question); ?></span>
                                <i class="fas fa-chevron-down text-primary transition-transform"></i>
                            </button>
                            <div class="faq-answer hidden px-6 py-4 bg-gray-50 border-t">
                                <p class="text-gray-600"><?php echo e($faq->answer); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-gray-600">Henüz SSS eklenmemiş.</p>
            <?php endif; ?>
            
            
            <div class="mt-12 bg-primary text-white rounded-lg p-8 text-center">
                <h3 class="text-2xl font-bold mb-4">Sorunuza cevap bulamadınız mı?</h3>
                <p class="mb-6">Bizimle iletişime geçin, size yardımcı olalım</p>
                <a href="<?php echo e(route('contact')); ?>" class="bg-white text-primary px-8 py-3 rounded-full hover:bg-gray-100 transition inline-block">
                    <i class="fas fa-envelope mr-2"></i> İletişime Geçin
                </a>
            </div>
        </div>
    </div>
</section>

<?php $__env->startPush('scripts'); ?>
<script>
    // FAQ Accordion
    document.querySelectorAll('.faq-question').forEach(button => {
        button.addEventListener('click', () => {
            const answer = button.nextElementSibling;
            const icon = button.querySelector('i');
            
            // Toggle answer visibility
            answer.classList.toggle('hidden');
            
            // Rotate icon
            if (answer.classList.contains('hidden')) {
                icon.style.transform = 'rotate(0deg)';
            } else {
                icon.style.transform = 'rotate(180deg)';
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/boztech/Desktop/ukpower/resources/views/pages/faq.blade.php ENDPATH**/ ?>