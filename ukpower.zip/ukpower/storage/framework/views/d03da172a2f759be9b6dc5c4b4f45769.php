<?php $__env->startSection('title', 'Blog - UKPower'); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-gradient-to-r from-blue-600 to-green-500 text-white py-16">
    <div class="container mx-auto px-4">
        <h1 class="text-4xl font-bold mb-4">Blog</h1>
        <p class="text-xl">Güneş enerjisi ve yenilenebilir enerji hakkında güncel bilgiler</p>
    </div>
</section>

<section class="py-16">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <div class="lg:col-span-2">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="bg-white rounded-lg shadow-md overflow-hidden hover-scale">
                        <div class="h-48 bg-gradient-to-br from-yellow-400 to-orange-400"></div>
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-2">
                                <i class="far fa-calendar mr-1"></i> <?php echo e($blog->published_at->format('d.m.Y')); ?>

                                <span class="mx-2">•</span>
                                <i class="far fa-eye mr-1"></i> <?php echo e($blog->views); ?> görüntülenme
                            </div>
                            <h3 class="text-xl font-semibold text-gray-900 mb-3"><?php echo e($blog->title); ?></h3>
                            <p class="text-gray-600 mb-4"><?php echo e(Str::limit($blog->excerpt, 100)); ?></p>
                            <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="text-primary font-semibold hover:underline">
                                Devamını Oku <i class="fas fa-arrow-right ml-1"></i>
                            </a>
                        </div>
                    </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="col-span-2 text-center text-gray-600">Henüz blog yazısı yok.</p>
                    <?php endif; ?>
                </div>
                
                
                <div class="mt-8">
                    <?php echo e($blogs->links()); ?>

                </div>
            </div>
            
            
            <div>
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h3 class="text-xl font-bold text-gray-900 mb-4">Popüler Yazılar</h3>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $popularBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('blog.show', $popular->slug)); ?>" class="block hover:text-primary transition">
                            <h4 class="font-semibold text-gray-900 mb-1"><?php echo e($popular->title); ?></h4>
                            <p class="text-sm text-gray-500">
                                <i class="far fa-eye mr-1"></i> <?php echo e($popular->views); ?> görüntülenme
                            </p>
                        </a>
                        <?php if(!$loop->last): ?>
                        <hr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/boztech/Desktop/ukpower/resources/views/blog/index.blade.php ENDPATH**/ ?>