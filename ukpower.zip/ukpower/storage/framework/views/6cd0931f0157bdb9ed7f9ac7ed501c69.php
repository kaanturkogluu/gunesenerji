<?php $__env->startSection('title', 'Hizmetlerimiz - UKPower'); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-gradient-to-r from-blue-600 to-green-500 text-white py-16">
    <div class="container mx-auto px-4">
        <h1 class="text-4xl font-bold mb-4">Hizmetlerimiz</h1>
        <p class="text-xl">Yenilenebilir enerji alanında profesyonel çözümler</p>
    </div>
</section>

<section class="py-16">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover-scale">
                <div class="p-8">
                    <div class="text-5xl text-primary mb-4">
                        <i class="fas fa-<?php echo e($service->icon ?? 'solar-panel'); ?>"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4"><?php echo e($service->title); ?></h3>
                    <p class="text-gray-600 mb-6"><?php echo e($service->short_description); ?></p>
                    <a href="<?php echo e(route('services.show', $service->slug)); ?>" class="bg-primary text-white px-6 py-3 rounded-full hover:bg-blue-700 transition inline-block">
                        Detaylı Bilgi <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/boztech/Desktop/ukpower/resources/views/services/index.blade.php ENDPATH**/ ?>