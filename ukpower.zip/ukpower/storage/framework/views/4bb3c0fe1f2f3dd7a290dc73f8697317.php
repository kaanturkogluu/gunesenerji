<?php $__env->startSection('title', 'UKPower - Güneş Enerjisi Çözümleri'); ?>

<?php $__env->startSection('content'); ?>

<section class="hero-gradient text-white py-24">
    <div class="container mx-auto px-4">
        <div class="max-w-4xl">
            <h1 class="text-4xl md:text-6xl font-bold mb-6">
                Güneş Enerjisiyle Geleceği Aydınlatıyoruz
            </h1>
            <p class="text-xl md:text-2xl mb-8 text-gray-100">
                Yenilenebilir enerji çözümleri ile hem çevreyi koruyun hem de enerji maliyetlerinizi düşürün.
            </p>
            <div class="flex flex-col sm:flex-row gap-4">
                <a href="<?php echo e(route('contact')); ?>" class="bg-white text-primary px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition inline-block text-center">
                    <i class="fas fa-envelope mr-2"></i> Hemen Teklif Alın
                </a>
                <a href="<?php echo e(route('projects')); ?>" class="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-primary transition inline-block text-center">
                    <i class="fas fa-folder-open mr-2"></i> Projelerimizi İnceleyin
                </a>
            </div>
        </div>
    </div>
</section>


<section class="bg-white py-16">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div class="hover-scale">
                <div class="text-4xl font-bold text-primary mb-2">15+</div>
                <div class="text-gray-600">Yıllık Tecrübe</div>
            </div>
            <div class="hover-scale">
                <div class="text-4xl font-bold text-primary mb-2">500+</div>
                <div class="text-gray-600">Tamamlanan Proje</div>
            </div>
            <div class="hover-scale">
                <div class="text-4xl font-bold text-primary mb-2">100+</div>
                <div class="text-gray-600">MW Kurulu Güç</div>
            </div>
            <div class="hover-scale">
                <div class="text-4xl font-bold text-primary mb-2">%98</div>
                <div class="text-gray-600">Müşteri Memnuniyeti</div>
            </div>
        </div>
    </div>
</section>


<section class="bg-gray-50 py-16">
    <div class="container mx-auto px-4">
        <div class="text-center mb-12">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Hizmetlerimiz</h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Güneş enerjisi sistemleri kurulumundan bakımına kadar tüm ihtiyaçlarınız için profesyonel hizmet
            </p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white p-6 rounded-lg shadow-md hover-scale">
                <div class="text-4xl text-primary mb-4">
                    <i class="fas fa-<?php echo e($service->icon ?? 'solar-panel'); ?>"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-900 mb-3"><?php echo e($service->title); ?></h3>
                <p class="text-gray-600 mb-4"><?php echo e(Str::limit($service->short_description, 100)); ?></p>
                <a href="<?php echo e(route('services.show', $service->slug)); ?>" class="text-primary font-semibold hover:underline">
                    Detaylı Bilgi <i class="fas fa-arrow-right ml-1"></i>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="text-center mt-8">
            <a href="<?php echo e(route('services')); ?>" class="bg-primary text-white px-8 py-3 rounded-full hover:bg-blue-700 transition inline-block">
                Tüm Hizmetlerimiz
            </a>
        </div>
    </div>
</section>


<section class="py-16">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                    Karbon Ayak İzini Azaltan Ekonomik Çözümler
                </h2>
                <p class="text-gray-600 mb-4">
                    UKPower olarak, 15+ yıllık uzman kadromuzla enerji santrali projeleri alanında danışmanlık, 
                    mühendislik, proje geliştirme ve denetim konularında hizmet vermekteyiz.
                </p>
                <p class="text-gray-600 mb-6">
                    Güneş Enerjisi Santralleri (GES) ve Rüzgar Santralleri (RES) kurulumlarında anahtar teslim 
                    projeler sunarak ülkemizin enerjisine değer katıyoruz.
                </p>
                <a href="<?php echo e(route('about')); ?>" class="bg-primary text-white px-8 py-3 rounded-full hover:bg-blue-700 transition inline-block">
                    Hakkımızda Daha Fazla
                </a>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div class="bg-gray-100 p-6 rounded-lg">
                    <i class="fas fa-award text-4xl text-primary mb-3"></i>
                    <h4 class="font-semibold text-gray-900 mb-2">Uluslararası Kalite</h4>
                    <p class="text-sm text-gray-600">ISO sertifikalı çalışma standartları</p>
                </div>
                <div class="bg-gray-100 p-6 rounded-lg">
                    <i class="fas fa-users text-4xl text-primary mb-3"></i>
                    <h4 class="font-semibold text-gray-900 mb-2">Uzman Kadro</h4>
                    <p class="text-sm text-gray-600">15+ yıl tecrübeli mühendisler</p>
                </div>
                <div class="bg-gray-100 p-6 rounded-lg">
                    <i class="fas fa-leaf text-4xl text-primary mb-3"></i>
                    <h4 class="font-semibold text-gray-900 mb-2">Çevre Dostu</h4>
                    <p class="text-sm text-gray-600">%100 yenilenebilir enerji</p>
                </div>
                <div class="bg-gray-100 p-6 rounded-lg">
                    <i class="fas fa-tools text-4xl text-primary mb-3"></i>
                    <h4 class="font-semibold text-gray-900 mb-2">Bakım Desteği</h4>
                    <p class="text-sm text-gray-600">7/24 teknik destek hizmeti</p>
                </div>
            </div>
        </div>
    </div>
</section>


<?php if($projects->count() > 0): ?>
<section class="bg-gray-50 py-16">
    <div class="container mx-auto px-4">
        <div class="text-center mb-12">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Öne Çıkan Projelerimiz</h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Türkiye'nin dört bir yanında gerçekleştirdiğimiz başarılı projeler
            </p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover-scale">
                <div class="h-48 bg-gradient-to-br from-blue-400 to-green-400"></div>
                <div class="p-6">
                    <div class="text-sm text-primary font-semibold mb-2">
                        <i class="fas fa-bolt mr-1"></i> <?php echo e($project->capacity ?? 'N/A'); ?>

                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo e($project->title); ?></h3>
                    <p class="text-gray-600 text-sm mb-4">
                        <i class="fas fa-map-marker-alt mr-1"></i> <?php echo e($project->location); ?>

                    </p>
                    <a href="<?php echo e(route('projects.show', $project->slug)); ?>" class="text-primary font-semibold hover:underline">
                        Detayları Görüntüle <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="text-center mt-8">
            <a href="<?php echo e(route('projects')); ?>" class="bg-primary text-white px-8 py-3 rounded-full hover:bg-blue-700 transition inline-block">
                Tüm Projeler
            </a>
        </div>
    </div>
</section>
<?php endif; ?>


<?php if($blogs->count() > 0): ?>
<section class="py-16">
    <div class="container mx-auto px-4">
        <div class="text-center mb-12">
            <h2 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Son Yazılar</h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                Güneş enerjisi ve yenilenebilir enerji hakkında güncel bilgiler
            </p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="bg-white rounded-lg shadow-md overflow-hidden hover-scale">
                <div class="h-48 bg-gradient-to-br from-yellow-400 to-orange-400"></div>
                <div class="p-6">
                    <div class="text-sm text-gray-500 mb-2">
                        <i class="far fa-calendar mr-1"></i> <?php echo e($blog->published_at->format('d.m.Y')); ?>

                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-3"><?php echo e($blog->title); ?></h3>
                    <p class="text-gray-600 mb-4"><?php echo e(Str::limit($blog->excerpt, 100)); ?></p>
                    <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="text-primary font-semibold hover:underline">
                        Devamını Oku <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="text-center mt-8">
            <a href="<?php echo e(route('blog')); ?>" class="bg-primary text-white px-8 py-3 rounded-full hover:bg-blue-700 transition inline-block">
                Tüm Yazılar
            </a>
        </div>
    </div>
</section>
<?php endif; ?>


<section class="hero-gradient text-white py-16">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl md:text-4xl font-bold mb-4">Güneş Enerjisiyle Tasarruf Etmeye Hazır mısınız?</h2>
        <p class="text-xl mb-8 text-gray-100">Ücretsiz keşif ve teklif için hemen iletişime geçin</p>
        <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="<?php echo e(route('contact')); ?>" class="bg-white text-primary px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition inline-block">
                <i class="fas fa-phone mr-2"></i> Bizi Arayın
            </a>
            <a href="<?php echo e(route('faq')); ?>" class="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-primary transition inline-block">
                <i class="fas fa-question-circle mr-2"></i> SSS
            </a>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/boztech/Desktop/ukpower/resources/views/home.blade.php ENDPATH**/ ?>