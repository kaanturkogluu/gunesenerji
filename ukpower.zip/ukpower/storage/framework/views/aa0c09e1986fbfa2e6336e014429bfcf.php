<?php $__env->startSection('title', 'Projelerimiz - UKPower'); ?>

<?php $__env->startSection('content'); ?>
<section class="bg-gradient-to-r from-blue-600 to-green-500 text-white py-16">
    <div class="container mx-auto px-4">
        <h1 class="text-4xl font-bold mb-4">Projelerimiz</h1>
        <p class="text-xl">Başarıyla tamamladığımız güneş ve rüzgar enerjisi projeleri</p>
    </div>
</section>

<section class="py-16">
    <div class="container mx-auto px-4">
        
        <div class="flex justify-center mb-8 flex-wrap gap-4">
            <a href="<?php echo e(route('projects')); ?>" class="px-6 py-2 rounded-full <?php echo e(!request('category') ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'); ?>">
                Tümü
            </a>
            <a href="<?php echo e(route('projects', ['category' => 'ges'])); ?>" class="px-6 py-2 rounded-full <?php echo e(request('category') == 'ges' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'); ?>">
                GES
            </a>
            <a href="<?php echo e(route('projects', ['category' => 'res'])); ?>" class="px-6 py-2 rounded-full <?php echo e(request('category') == 'res' ? 'bg-primary text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'); ?>">
                RES
            </a>
        </div>
        
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover-scale">
                <div class="h-48 bg-gradient-to-br from-blue-400 to-green-400"></div>
                <div class="p-6">
                    <div class="text-sm text-primary font-semibold mb-2">
                        <i class="fas fa-bolt mr-1"></i> <?php echo e($project->capacity ?? 'N/A'); ?>

                    </div>
                    <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo e($project->title); ?></h3>
                    <p class="text-gray-600 text-sm mb-4">
                        <i class="fas fa-map-marker-alt mr-1"></i> <?php echo e($project->location); ?>

                    </p>
                    <a href="<?php echo e(route('projects.show', $project->slug)); ?>" class="text-primary font-semibold hover:underline">
                        Detayları Görüntüle <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-3 text-center py-12">
                <p class="text-gray-600">Henüz proje eklenmemiş.</p>
            </div>
            <?php endif; ?>
        </div>
        
        
        <div class="mt-8">
            <?php echo e($projects->links()); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/boztech/Desktop/ukpower/resources/views/projects/index.blade.php ENDPATH**/ ?>